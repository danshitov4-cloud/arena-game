using System;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Orchestrator.Editor
{
    public static class CommandDispatcher
    {
        public static CommandResponse Execute(CommandRequest req)
        {
            req.id ??= Guid.NewGuid().ToString("N");

            switch (req.command)
            {
                case "ping":
                    return new CommandResponse
                    {
                        id = req.id,
                        ok = true,
                        result = new
                        {
                            unityVersion = Application.unityVersion,
                            project = Application.productName,
                            scene = SceneManager.GetActiveScene().name,
                            dispatcherVersion = "v2-with-getComponents"
                        }
                    };

                case "scene.scan":
                    return new CommandResponse
                    {
                        id = req.id,
                        ok = true,
                        result = SceneScanner.ScanActiveScene()
                    };


                case "scene.workflow.last":
                    return new CommandResponse { id = req.id, ok = true, result = WorkflowCommands.Last(req.args) };
                case "scene.snapshot.latest":
                    return new CommandResponse { id = req.id, ok = true, result = SnapshotCommands.Latest(req.args) };

                case "scene.snapshot.restoreLatest":
                    return new CommandResponse { id = req.id, ok = true, result = SnapshotCommands.RestoreLatest(req.args) };
                case "scene.snapshot.take":
                    return new CommandResponse { id = req.id, ok = true, result = SnapshotCommands.Take(req.args) };
                case "materials.workflow.cancelRestore":
                    return new CommandResponse { id = req.id, ok = true, result = MaterialsWorkflow.CancelScheduledRestore(req.args) };

                case "scene.snapshot.restore":
                    return new CommandResponse { id = req.id, ok = true, result = SnapshotCommands.Restore(req.args) };

                case "scene.snapshot.list":
                    return new CommandResponse { id = req.id, ok = true, result = SnapshotCommands.List(req.args) };

                case "scene.snapshot.delete":
                    return new CommandResponse { id = req.id, ok = true, result = SnapshotCommands.Delete(req.args) };
                case "scene.snapshot.save":
                    return new CommandResponse { id = req.id, ok = true, result = SnapshotCommands.Save(req.args) };
                case "scene.query":
                    return new CommandResponse { id = req.id, ok = true, result = SceneQuery.Query(req.args) };

                case "scene.selectByQuery":
                    return new CommandResponse { id = req.id, ok = true, result = SceneQuery.SelectByQuery(req.args) };

                case "scene.batch.addComponent":
                    return new CommandResponse { id = req.id, ok = true, result = SceneBatch.AddComponent(req.args) };

                case "scene.batch.setComponentEnabled":
                    return new CommandResponse { id = req.id, ok = true, result = SceneBatch.SetComponentEnabled(req.args) };
                case "scene.batch.offsetTransform":
                    return new CommandResponse { id = req.id, ok = true, result = SceneBatchTransforms.OffsetTransform(req.args) };
                case "scene.snapshot.load":
                    return new CommandResponse { id = req.id, ok = true, result = SnapshotCommands.Load(req.args) };
                case "scene.batch.diffComponentProperties":
                    return new CommandResponse { id = req.id, ok = true, result = SceneBatchProps.DiffComponentProperties(req.args) };
                case "scene.batch.setComponentProperties":
                    return new CommandResponse { id = req.id, ok = true, result = SceneBatchProps.SetComponentProperties(req.args) };
                case "materials.report":
                    return new CommandResponse { id = req.id, ok = true, result = MaterialsCommands.Report(req.args) };
                case "scene.batch.applyIfDiffComponentProperties":
                    return new CommandResponse { id = req.id, ok = true, result = SceneBatchProps.ApplyIfDiffComponentProperties(req.args) };
                case "scene.batch.getComponentProperty":
                    return new CommandResponse { id = req.id, ok = true, result = SceneBatchProps.GetComponentProperty(req.args) };
                case "materials.presets.applyAutoTarget":
                    return new CommandResponse { id = req.id, ok = true, result = MaterialsToolkit.PresetsApplyAutoTarget(req.args) };
                case "scene.batch.setComponentProperty":
                    return new CommandResponse { id = req.id, ok = true, result = SceneBatchProps.SetComponentProperty(req.args) };

                case "scene.batch.removeComponent":
                    return new CommandResponse { id = req.id, ok = true, result = SceneBatchProps.RemoveComponent(req.args) };
                case "materials.findUsage":
                    return new CommandResponse { id = req.id, ok = true, result = MaterialsCommands.FindUsage(req.args) };
                case "materials.reportRich":
                    return new CommandResponse { id = req.id, ok = true, result = MaterialsToolkit.ReportRich(req.args) };
                case "materials.workflow.applyPresetAutoTargetDelay":
                    return new CommandResponse { id = req.id, ok = true, result = MaterialsWorkflow.ApplyPresetAutoTargetDelay(req.args) };
                case "materials.presets.list":
                    return new CommandResponse { id = req.id, ok = true, result = MaterialsToolkit.ListPresets(req.args) };
                case "materials.setColorAuto":
                    return new CommandResponse { id = req.id, ok = true, result = MaterialsToolkit.SetColorAuto(req.args) };
                case "materials.applyPresetAutoTarget":
                    return new CommandResponse { id = req.id, ok = true, result = MaterialsToolkit.ApplyPresetAutoTarget(req.args) };
                case "materials.snapshot.take":
                    return new CommandResponse { id = req.id, ok = true, result = MaterialSnapshotCommands.Take(req.args) };
                    
                case "materials.snapshot.restore":
                    return new CommandResponse { id = req.id, ok = true, result = MaterialSnapshotCommands.Restore(req.args) };
                    
                case "materials.snapshot.list":
                    return new CommandResponse { id = req.id, ok = true, result = MaterialSnapshotCommands.List(req.args) };
                case "materials.snapshot.save": return new CommandResponse { id = req.id, ok = true, result = MaterialSnapshotCommands.Save(req.args) };
                case "materials.snapshot.load": return new CommandResponse { id = req.id, ok = true, result = MaterialSnapshotCommands.Load(req.args) };
                case "materials.snapshot.latest":
                    return new CommandResponse { id = req.id, ok = true, result = MaterialSnapshotCommands.Latest(req.args) };

                case "materials.workflow.testPresetAutoTargetV2":
                    return new CommandResponse { id = req.id, ok = true, result = MaterialsToolkit.WorkflowTestPresetAutoTargetV2(req.args) };
                case "materials.applyPreset":
                    return new CommandResponse { id = req.id, ok = true, result = MaterialsToolkit.ApplyPreset(req.args) };
                case "materials.workflow.testPresetAutoTarget":
                    return new CommandResponse { id = req.id, ok = true, result = MaterialsToolkit.WorkflowTestPresetAutoTarget(req.args) };
                case "materials.setColorByObjectNameContains":
                    return new CommandResponse { id = req.id, ok = true, result = MaterialsCommands.SetColorByObjectNameContains(req.args) };
                case "scene.batch.setAxis":
                    return new CommandResponse { id = req.id, ok = true, result = SceneBatchTransforms.SetAxis(req.args) };
                case "help.schema":
                    return new CommandResponse { id = req.id, ok = true, result = HelpSchema.GetSchema(req.args) };
                case "scene.batch.setParentByQuery":
                    return new CommandResponse { id = req.id, ok = true, result = SceneHierarchyCommands.SetParentByQuery(req.args) };
                case "scene.batch.renameByQuery":
                    return new CommandResponse { id = req.id, ok = true, result = SceneHierarchyCommands.RenameByQuery(req.args) };
                case "scene.prefab.report":
                    return new CommandResponse { id = req.id, ok = true, result = ScenePrefabReportCommands.Report(req.args) };
                case "scene.ref.setFieldByQuerySelf":
                    return new CommandResponse { id = req.id, ok = true, result = SceneReferenceCommands.SetFieldByQuerySelf(req.args) };


                case "project.assets.find":
                    return new CommandResponse { id = req.id, ok = true, result = ProjectAssetsCommands.Find(req.args) };
                case "project.assets.inspect":
                    return new CommandResponse { id = req.id, ok = true, result = ProjectAssetsInspectCommands.Inspect(req.args) };

                case "project.scripts.read":
                    return new CommandResponse { id = req.id, ok = true, result = ProjectScriptsPatchCommands.Read(req.args) };
                case "project.compilation.wait":
                    return new CommandResponse { id = req.id, ok = true, result = ProjectCompilationCommands.Wait(req.args) };

                case "project.scripts.patch":
                    return new CommandResponse { id = req.id, ok = true, result = ProjectScriptsPatchCommands.Patch(req.args) };

                case "prefab.instantiate":
                    return new CommandResponse { id = req.id, ok = true, result = PrefabInstantiateCommands.Instantiate(req.args) };
                case "project.compilation.status":
                    return new CommandResponse { id = req.id, ok = true, result = ProjectCompilationCommands.Status(req.args) };

                case "project.compilation.errors":
                    return new CommandResponse { id = req.id, ok = true, result = ProjectCompilationCommands.Errors(req.args) };

                case "project.scripts.create":
                    return new CommandResponse { id = req.id, ok = true, result = ProjectScriptsCommands.Create(req.args) };

                case "scene.ref.setFieldByQuery":
                    return new CommandResponse { id = req.id, ok = true, result = SceneReferenceCommands.SetFieldByQuery(req.args) };
                case "scene.ref.describe":
                    return new CommandResponse { id = req.id, ok = true, result = SceneReferenceCommands.Describe(req.args) };

                case "scene.batch.duplicateByQuery":
                    return new CommandResponse { id = req.id, ok = true, result = SceneHierarchyCommands.DuplicateByQuery(req.args) };
                case "prefab.applyOverridesByQuery":
                    return new CommandResponse { id = req.id, ok = true, result = PrefabCommands.ApplyOverridesByQuery(req.args) };

                case "prefab.revertOverridesByQuery":
                    return new CommandResponse { id = req.id, ok = true, result = PrefabCommands.RevertOverridesByQuery(req.args) };
                case "asset.ref.setFieldByQuery":
                    return new CommandResponse { id = req.id, ok = true, result = AssetReferenceCommands.SetFieldByQuery(req.args) };

                case "prefab.unpackByQuery":
                    return new CommandResponse { id = req.id, ok = true, result = PrefabCommands.UnpackByQuery(req.args) };

                case "help.commands":
                    return new CommandResponse { id = req.id, ok = true, result = HelpSchema.GetCommands(req.args) };
                case "scene.deleteByName":
                    return new CommandResponse { id = req.id, ok = true, result = SceneDeleteCommands.DeleteByName(req.args) };
                case "scene.setActiveByQuery":
                    return new CommandResponse { id = req.id, ok = true, result = SceneGameObjectCommands.SetActiveByQuery(req.args) };

                case "scene.deleteByQuery":
                    return new CommandResponse { id = req.id, ok = true, result = SceneGameObjectCommands.DeleteByQuery(req.args) };

                case "scene.destroyChildrenOf":
                    return new CommandResponse { id = req.id, ok = true, result = SceneGameObjectCommands.DestroyChildrenOf(req.args) };

                case "help.command":
                    return new CommandResponse { id = req.id, ok = true, result = HelpSchema.GetCommand(req.args) };
                case "materials.replaceByObjectNameContains":
                    return new CommandResponse { id = req.id, ok = true, result = MaterialsCommands.ReplaceByObjectNameContains(req.args) };
                case "scene.batch.placePrefabGrid":
                    return new CommandResponse { id = req.id, ok = true, result = SceneBatchTransforms.PlacePrefabGrid(req.args) };
                case "scene.batch.snapToGrid":
                    return new CommandResponse { id = req.id, ok = true, result = SceneBatchTransforms.SnapToGrid(req.args) };
                case "materials.inspect":
                    return new CommandResponse { id = req.id, ok = true, result = MaterialsToolkit.Inspect(req.args) };
                case "scene.batch.setTransform":
                    return new CommandResponse { id = req.id, ok = true, result = SceneBatchTransforms.SetTransform(req.args) };

                case "materials.setProperty":
                    return new CommandResponse { id = req.id, ok = true, result = MaterialsToolkit.SetProperty(req.args) };

                case "materials.setColorByMaterialNameContains":
                    return new CommandResponse { id = req.id, ok = true, result = MaterialsToolkit.SetColorByMaterialNameContains(req.args) };

                case "materials.replaceByMaterialNameContains":
                    return new CommandResponse { id = req.id, ok = true, result = MaterialsToolkit.ReplaceByMaterialNameContains(req.args) };
                case "scene.optimize.restore":
                    return new CommandResponse
                    {
                        id = req.id,
                        ok = true,
                        result = OptimizerRestore.Restore(req.args)
                    };
                case "scene.report.updates":
                    return new CommandResponse
                    {
                        id = req.id,
                        ok = true,
                        result = SceneReports.Updates()
                    };
                case "scene.optimize.apply":
                    return new CommandResponse
                    {
                        id = req.id,
                        ok = true,
                        result = OptimizerApply.Apply(req.args)
                    };
                case "scene.report.instancesByType":
                    return new CommandResponse
                    {
                        id = req.id,
                        ok = true,
                        result = InstanceReports.InstancesByType(req.args)
                    };
                case "scene.batchSetEnabledByType":
                    return new CommandResponse
                    {
                        id = req.id,
                        ok = true,
                        result = BatchCommands.BatchSetEnabledByType(req.args)
                    };
                case "scene.optimize.plan":
                    return new CommandResponse
                    {
                        id = req.id,
                        ok = true,
                        result = OptimizerPlan.BuildPlan()
                    };

                case "scene.find":
                    return new CommandResponse
                    {
                        id = req.id,
                        ok = true,
                        result = SceneCommands.Find(req.args)
                    };

                case "scene.setTransform":
                    return new CommandResponse
                    {
                        id = req.id,
                        ok = true,
                        result = SceneMutations.SetTransform(req.args)
                    };
                case "scene.report.renderers":
                    return new CommandResponse
                    {
                        id = req.id,
                        ok = true,
                        result = RenderReports.Renderers()
                    };
                case "scene.select":
                    return new CommandResponse
                    {
                        id = req.id,
                        ok = true,
                        result = SceneCommands.Select(req.args)
                    };
                case "scene.createEmpty":
                    return new CommandResponse
                    {
                        id = req.id,
                        ok = true,
                        result = SceneMutations.CreateEmpty(req.args)
                    };
                case "scene.addPrefab":
                    return new CommandResponse
                    {
                        id = req.id,
                        ok = true,
                        result = SceneMutations.AddPrefab(req.args)
                    };
                case "scene.getComponents":
                    return new CommandResponse
                    {
                        id = req.id,
                        ok = true,
                        result = SceneCommands.GetComponents(req.args)

                    };
                case "component.setEnabled":
                    return new CommandResponse
                    {
                        id = req.id,
                        ok = true,
                        result = ComponentCommands.SetEnabled(req.args)
                    };
                case "help.dump":
                    return new CommandResponse { id = req.id, ok = true, result = HelpSchema.Dump(req.args) };
                case "help.save":
                    return new CommandResponse { id = req.id, ok = true, result = HelpSchema.Save(req.args) };

                case "help.load":
                    return new CommandResponse { id = req.id, ok = true, result = HelpSchema.Load(req.args) };
                case "help.open":
                    return new CommandResponse { id = req.id, ok = true, result = HelpSchema.Open(req.args) };
                case "help.exportMarkdown":
                    return new CommandResponse { id = req.id, ok = true, result = HelpSchema.ExportMarkdown(req.args) };
                case "project.exportContext":
                    return new CommandResponse { id = req.id, ok = true, result = ExportContextCommands.Export(req.args) };
                case "scene.workflow.run":
                    return new CommandResponse { id = req.id, ok = true, result = WorkflowCommands.Run(req.args) };

                case "scene.workflow.cancelRestore":
                    return new CommandResponse { id = req.id, ok = true, result = WorkflowCommands.CancelScheduledRestore(req.args) };

                






                default:
                    return new CommandResponse
                    {
                        id = req.id,
                        ok = false,
                        error = $"Unknown command: {req.command}"
                    };

            }
        }
    }
}